import streamlit as st
import json
import datetime
from utils.claude_api import ask_claude

DEFAULT_DECKS = {
    "🎬 Cinema & Séries": [
        {"en": "plot twist", "pt": "reviravolta na trama", "example": "The plot twist at the end left everyone shocked.", "level": 0, "next_review": ""},
        {"en": "binge-watch", "pt": "maratonar (séries)", "example": "I binge-watched the entire season over the weekend.", "level": 0, "next_review": ""},
        {"en": "cliffhanger", "pt": "final suspenso/em aberto", "example": "The season finale ended on a cliffhanger!", "level": 0, "next_review": ""},
        {"en": "spoiler", "pt": "spoiler (revelar algo)", "example": "Don't spoil the movie for me!", "level": 0, "next_review": ""},
        {"en": "blockbuster", "pt": "grande sucesso de bilheteria", "example": "Avengers is a massive blockbuster.", "level": 0, "next_review": ""},
        {"en": "sequel", "pt": "continuação/sequência", "example": "The sequel was even better than the original.", "level": 0, "next_review": ""},
        {"en": "subtitles", "pt": "legendas", "example": "I always watch foreign films with subtitles.", "level": 0, "next_review": ""},
        {"en": "cast", "pt": "elenco", "example": "The cast of this series is incredible.", "level": 0, "next_review": ""},
    ],
    "💼 Inglês do Dia a Dia": [
        {"en": "hang out", "pt": "sair/ficar com amigos", "example": "Do you want to hang out this weekend?", "level": 0, "next_review": ""},
        {"en": "figure out", "pt": "descobrir/resolver", "example": "I can't figure out this problem.", "level": 0, "next_review": ""},
        {"en": "give up", "pt": "desistir", "example": "Don't give up on your dreams!", "level": 0, "next_review": ""},
        {"en": "look forward to", "pt": "estar ansioso por algo", "example": "I'm looking forward to the weekend.", "level": 0, "next_review": ""},
        {"en": "by the way", "pt": "a propósito / aliás", "example": "By the way, did you see that movie?", "level": 0, "next_review": ""},
        {"en": "make up your mind", "pt": "tomar uma decisão", "example": "You need to make up your mind!", "level": 0, "next_review": ""},
        {"en": "deal with", "pt": "lidar com", "example": "I have to deal with a lot of stress.", "level": 0, "next_review": ""},
        {"en": "catch up", "pt": "se atualizar / colocar o papo em dia", "example": "Let's catch up over coffee!", "level": 0, "next_review": ""},
    ],
    "🧠 Gramática Rápida": [
        {"en": "I used to + verb", "pt": "Eu costumava (passado habitual)", "example": "I used to watch cartoons every morning.", "level": 0, "next_review": ""},
        {"en": "I wish + past", "pt": "Queria que... (desejo irreal)", "example": "I wish I spoke perfect English.", "level": 0, "next_review": ""},
        {"en": "Have you ever...?", "pt": "Você já...? (present perfect)", "example": "Have you ever been to New York?", "level": 0, "next_review": ""},
        {"en": "used to vs. would", "pt": "hábito passado (used to = estado/ação; would = só ação)", "example": "I used to be shy. I would practice daily.", "level": 0, "next_review": ""},
    ],
}

INTERVAL_DAYS = [0, 1, 3, 7, 14, 30]

def get_due_cards(deck):
    today = datetime.date.today().isoformat()
    due = []
    for i, card in enumerate(deck):
        if not card["next_review"] or card["next_review"] <= today:
            due.append(i)
    return due

def update_card_review(deck, idx, quality):
    card = deck[idx]
    level = card.get("level", 0)
    if quality >= 3:
        level = min(level + 1, len(INTERVAL_DAYS) - 1)
    else:
        level = max(level - 1, 0)
    days = INTERVAL_DAYS[level]
    next_date = (datetime.date.today() + datetime.timedelta(days=days)).isoformat()
    deck[idx]["level"] = level
    deck[idx]["next_review"] = next_date
    return deck

def render_flashcards():
    st.markdown("<h2>🃏 Flashcards com Revisão Espaçada</h2>", unsafe_allow_html=True)
    st.markdown("<p class='muted-text'>Memorize vocabulário de forma eficiente com o método de repetição espaçada (SRS).</p>", unsafe_allow_html=True)

    # Init state
    if "flashcard_decks" not in st.session_state:
        st.session_state.flashcard_decks = {k: list(v) for k, v in DEFAULT_DECKS.items()}
    if "current_deck_name" not in st.session_state:
        st.session_state.current_deck_name = list(DEFAULT_DECKS.keys())[0]
    if "fc_index" not in st.session_state:
        st.session_state.fc_index = 0
    if "fc_show_answer" not in st.session_state:
        st.session_state.fc_show_answer = False
    if "fc_due" not in st.session_state:
        st.session_state.fc_due = []

    tab_study, tab_manage, tab_ai_gen = st.tabs(["📚 Estudar", "🗂️ Gerenciar Baralhos", "✨ Gerar com IA"])

    # ── STUDY TAB ──
    with tab_study:
        col_deck, col_stats = st.columns([2, 1])
        with col_deck:
            deck_name = st.selectbox("Baralho:", list(st.session_state.flashcard_decks.keys()), label_visibility="collapsed")
            st.session_state.current_deck_name = deck_name

        deck = st.session_state.flashcard_decks[deck_name]
        due_indices = get_due_cards(deck)

        with col_stats:
            st.markdown(f"""
            <div style='padding: 0.5rem 0;'>
                <span style='color:#E8FF47; font-weight:700; font-size:1.2rem;'>{len(due_indices)}</span>
                <span class='muted-text'> para revisar hoje</span>
                &nbsp;|&nbsp;
                <span style='color:#47CFFF; font-weight:700;'>{len(deck)}</span>
                <span class='muted-text'> total</span>
            </div>
            """, unsafe_allow_html=True)

        if not due_indices:
            st.markdown("""
            <div style='text-align:center; padding: 3rem;'>
                <div style='font-size:3rem;'>🎉</div>
                <h3 style='color:#E8FF47;'>Tudo em dia!</h3>
                <p class='muted-text'>Você revisou todos os cards por hoje. Volte amanhã!</p>
            </div>
            """, unsafe_allow_html=True)
        else:
            # Current card
            if st.session_state.fc_index >= len(due_indices):
                st.session_state.fc_index = 0

            card_idx = due_indices[st.session_state.fc_index]
            card = deck[card_idx]

            progress = st.session_state.fc_index / len(due_indices)
            st.progress(progress)
            st.markdown(f"<div class='muted-text' style='text-align:right;'>{st.session_state.fc_index + 1} / {len(due_indices)}</div>", unsafe_allow_html=True)

            # Flashcard display
            level_labels = ["🌱 Novo", "🔵 Fácil", "🟡 Médio", "🟠 Difícil", "🟢 Dominado", "⭐ Expert"]
            lvl = card.get("level", 0)

            st.markdown(f"""
            <div class='flashcard'>
                <div style='font-size:0.75rem; color:#7A7A8A; letter-spacing:2px; text-transform:uppercase; margin-bottom:1rem;'>🇺🇸 Inglês</div>
                <div style='font-size:2rem; font-family: Syne, sans-serif; font-weight:800; color:#E8FF47; margin-bottom:0.5rem;'>{card["en"]}</div>
                <div style='font-size:0.8rem; color:#7A7A8A; margin-top:0.5rem;'>{level_labels[min(lvl, len(level_labels)-1)]}</div>
            </div>
            """, unsafe_allow_html=True)

            col_flip, col_ex = st.columns([1, 1])
            with col_flip:
                if st.button("👁️ Ver resposta" if not st.session_state.fc_show_answer else "🙈 Esconder", use_container_width=True):
                    st.session_state.fc_show_answer = not st.session_state.fc_show_answer
                    st.rerun()

            if st.session_state.fc_show_answer:
                st.markdown(f"""
                <div class='card' style='text-align:center; border-color:#47CFFF; margin-top:0.5rem;'>
                    <div style='font-size:0.75rem; color:#47CFFF; letter-spacing:2px; text-transform:uppercase; margin-bottom:0.5rem;'>🇧🇷 Português</div>
                    <div style='font-size:1.4rem; font-weight:600; color:#F0EFE9; margin-bottom:0.8rem;'>{card["pt"]}</div>
                    <div style='font-size:0.85rem; color:#7A7A8A; font-style:italic;'>"{card["example"]}"</div>
                </div>
                """, unsafe_allow_html=True)

                st.markdown("**Quão bem você lembrou?**")
                col1, col2, col3, col4 = st.columns(4)
                ratings = [
                    (col1, "😰 Errei", 0, "#FF6B6B"),
                    (col2, "🤔 Difícil", 2, "#FF9F47"),
                    (col3, "😊 Lembrei", 3, "#E8FF47"),
                    (col4, "🚀 Fácil!", 5, "#47CFFF"),
                ]

                for col, label, quality, color in ratings:
                    with col:
                        if st.button(label, use_container_width=True, key=f"rate_{quality}"):
                            st.session_state.flashcard_decks[deck_name] = update_card_review(
                                st.session_state.flashcard_decks[deck_name], card_idx, quality
                            )
                            st.session_state.fc_index += 1
                            st.session_state.fc_show_answer = False
                            st.session_state.xp += (quality + 1) * 3
                            st.rerun()

    # ── MANAGE TAB ──
    with tab_manage:
        st.markdown("### ➕ Adicionar card manualmente")
        target_deck = st.selectbox("Adicionar ao baralho:", list(st.session_state.flashcard_decks.keys()), key="add_to_deck")
        col_en, col_pt = st.columns(2)
        with col_en:
            new_en = st.text_input("Palavra/expressão em inglês")
        with col_pt:
            new_pt = st.text_input("Tradução em português")
        new_ex = st.text_input("Exemplo de uso (em inglês)")

        if st.button("💾 Adicionar card") and new_en and new_pt:
            st.session_state.flashcard_decks[target_deck].append({
                "en": new_en, "pt": new_pt,
                "example": new_ex or f"I use '{new_en}' in my daily life.",
                "level": 0, "next_review": ""
            })
            st.success(f"✅ Card '{new_en}' adicionado ao baralho '{target_deck}'!")

        st.markdown("### 🗑️ Criar novo baralho")
        new_deck_name = st.text_input("Nome do novo baralho (ex: '🏖️ Viagens')")
        if st.button("Criar baralho") and new_deck_name:
            if new_deck_name not in st.session_state.flashcard_decks:
                st.session_state.flashcard_decks[new_deck_name] = []
                st.success(f"Baralho '{new_deck_name}' criado!")
            else:
                st.warning("Baralho já existe!")

    # ── AI GENERATION TAB ──
    with tab_ai_gen:
        st.markdown("### ✨ Gerar flashcards com IA")
        st.markdown("<p class='muted-text'>Descreva um tema e a IA criará flashcards personalizados para você!</p>", unsafe_allow_html=True)

        gen_topic = st.text_input("Tema ou contexto:", placeholder="Ex: vocabulário de restaurante, phrasal verbs com 'get', termos de tecnologia...")
        gen_qty = st.slider("Quantidade de cards:", 3, 15, 8)
        gen_level = st.select_slider("Nível:", ["Básico", "Intermediário", "Avançado"], value="Intermediário")
        gen_deck = st.selectbox("Adicionar ao baralho:", list(st.session_state.flashcard_decks.keys()), key="gen_deck")

        if st.button("🤖 Gerar Flashcards com IA", use_container_width=True):
            if not st.session_state.api_key:
                st.error("Insira sua API Key!")
            elif not gen_topic.strip():
                st.warning("Descreva um tema!")
            else:
                with st.spinner(f"Gerando {gen_qty} flashcards sobre '{gen_topic}'..."):
                    prompt = f"""Create {gen_qty} English flashcards for a Brazilian Portuguese speaker at {gen_level} level about: {gen_topic}

Return ONLY a JSON array, no other text:
[
  {{"en": "expression in English", "pt": "tradução em português", "example": "Example sentence in English."}},
  ...
]

Focus on practical, useful expressions. Make examples natural and context-appropriate."""

                    response = ask_claude(prompt, st.session_state.api_key)
                    if response:
                        try:
                            # Extract JSON from response
                            import re
                            json_match = re.search(r'\[.*?\]', response, re.DOTALL)
                            if json_match:
                                cards_data = json.loads(json_match.group())
                                added = 0
                                for c in cards_data:
                                    if "en" in c and "pt" in c:
                                        st.session_state.flashcard_decks[gen_deck].append({
                                            "en": c["en"], "pt": c["pt"],
                                            "example": c.get("example", f"Example with {c['en']}."),
                                            "level": 0, "next_review": ""
                                        })
                                        added += 1
                                st.success(f"✅ {added} flashcards adicionados ao baralho '{gen_deck}'!")
                                st.session_state.xp += added * 5
                                st.rerun()
                        except Exception as e:
                            st.error(f"Erro ao processar flashcards. Tente novamente. ({e})")
