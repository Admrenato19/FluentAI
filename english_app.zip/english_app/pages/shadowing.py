import streamlit as st
from utils.claude_api import ask_claude

SAMPLE_SCENES = {
    "🦁 O Rei Leão — 'Remember who you are'": {
        "en": "You have forgotten who you are and so have forgotten me. Look inside yourself, Simba. You are more than what you have become. You must take your place in the Circle of Life.",
        "pt": "Você esqueceu quem você é e, por isso, me esqueceu também. Olhe dentro de si mesmo, Simba. Você é mais do que se tornou. Você deve assumir seu lugar no Ciclo da Vida.",
        "vocab": ["forgotten", "inside yourself", "Circle of Life", "become"],
        "level": "Intermediário",
        "tips": "Preste atenção nas contrações: 'you have' → 'you've'. Repita a fala do Mufasa com voz grave e pausada.",
    },
    "🕷️ Homem-Aranha — 'Great power, great responsibility'": {
        "en": "With great power comes great responsibility. This is my gift, my curse. Who am I? I'm Spider-Man.",
        "pt": "Com grande poder vem grande responsabilidade. Esse é meu dom, minha maldição. Quem sou eu? Sou o Homem-Aranha.",
        "vocab": ["responsibility", "gift", "curse"],
        "level": "Básico",
        "tips": "Frase curta e rítmica — ótima para shadowing. Repita 5x acelerando progressivamente.",
    },
    "🧙 Harry Potter — Plataforma 9¾": {
        "en": "It's the same every year, packed with Muggles of course. Come on. Platform nine and three-quarters this way! Not to worry. Not to worry.",
        "pt": "É a mesma coisa todo ano, cheio de Trouxas claro. Venha. Plataforma nove e três quartos por aqui! Não se preocupe. Não se preocupe.",
        "vocab": ["packed", "Muggles", "platform", "three-quarters"],
        "level": "Intermediário",
        "tips": "Note o sotaque britânico. 'Three-quarters' é pronunciado 'three-KWORters'.",
    },
    "🤖 Interestelar — Cooper e Murph": {
        "en": "We used to look up at the sky and wonder at our place in the stars. Now we just look down and worry about our place in the dirt.",
        "pt": "Costumávamos olhar para o céu e nos perguntar sobre nosso lugar nas estrelas. Agora apenas olhamos para baixo e nos preocupamos com nosso lugar na terra.",
        "vocab": ["wonder", "place in the stars", "dirt"],
        "level": "Avançado",
        "tips": "Fala poética e lenta. Imite o ritmo melancólico do Cooper. Bom para entonação.",
    },
    "🧠 Breaking Bad — 'I am the danger'": {
        "en": "I am not in danger, Skyler. I am the danger. A guy opens his door and gets shot, and you think that of me? No. I am the one who knocks.",
        "pt": "Eu não estou em perigo, Skyler. Eu sou o perigo. Um cara abre a porta e leva um tiro, e você pensa isso de mim? Não. Sou eu quem bate.",
        "vocab": ["danger", "opens his door", "the one who knocks"],
        "level": "Intermediário",
        "tips": "Fala icônica! Pratique a pausa dramática antes de 'I am the danger'. Walter White fala devagar e com intensidade.",
    },
}

def render_shadowing():
    st.markdown("<h2>🎬 Shadowing com Filmes & Séries</h2>", unsafe_allow_html=True)
    st.markdown("<p class='muted-text'>Escolha uma cena, leia a legenda, repita em voz alta e peça feedback da IA.</p>", unsafe_allow_html=True)

    col_sel, col_info = st.columns([2, 1])

    with col_sel:
        scene_name = st.selectbox("Escolha uma cena", list(SAMPLE_SCENES.keys()), label_visibility="collapsed")

    scene = SAMPLE_SCENES[scene_name]

    with col_info:
        level_color = {"Básico": "#47CFFF", "Intermediário": "#E8FF47", "Avançado": "#FF6B6B"}.get(scene["level"], "#E8FF47")
        st.markdown(f"<div style='padding-top:0.5rem'><span style='background:{level_color}22; color:{level_color}; border:1px solid {level_color}55; border-radius:20px; padding:4px 14px; font-size:0.85rem; font-weight:600;'>{scene['level']}</span></div>", unsafe_allow_html=True)

    # Scene display
    st.markdown(f"""
    <div class='card-accent' style='margin-top:1rem;'>
        <div style='font-size:0.75rem; color:#7A7A8A; letter-spacing:2px; text-transform:uppercase; margin-bottom:0.8rem;'>🇺🇸 Original</div>
        <div style='font-size:1.2rem; line-height:1.8; font-weight:500; color:#F0EFE9;'>"{scene['en']}"</div>
    </div>
    """, unsafe_allow_html=True)

    show_pt = st.checkbox("📖 Mostrar tradução em português")
    if show_pt:
        st.markdown(f"""
        <div class='card' style='border-color:#47CFFF44;'>
            <div style='font-size:0.75rem; color:#47CFFF; letter-spacing:2px; text-transform:uppercase; margin-bottom:0.5rem;'>🇧🇷 Tradução</div>
            <div style='color:#B0B0C0; line-height:1.7;'>"{scene['pt']}"</div>
        </div>
        """, unsafe_allow_html=True)

    # Vocab highlights
    st.markdown(f"""
    <div style='margin: 0.5rem 0 1rem;'>
        <span style='font-size:0.8rem; color:#7A7A8A;'>📌 Vocabulário chave: </span>
        {"".join(f"<span class='tag'>{w}</span>" for w in scene['vocab'])}
    </div>
    """, unsafe_allow_html=True)

    # Tips
    st.info(f"💡 **Dica de pronúncia:** {scene['tips']}")

    st.markdown("---")
    st.markdown("### 🎙️ Pratique e receba feedback")

    col_steps, col_method = st.columns([1, 1])
    with col_steps:
        st.markdown("""
        <div class='card'>
            <b style='color:#E8FF47;'>Como fazer shadowing:</b><br><br>
            <b>1.</b> Leia o texto em voz alta (sem áudio) <br>
            <b>2.</b> Escreva sua versão falada abaixo <br>
            <b>3.</b> Peça análise da IA <br>
            <b>4.</b> Repita 3–5x até soar natural
        </div>
        """, unsafe_allow_html=True)
    with col_method:
        st.markdown("""
        <div class='card'>
            <b style='color:#47CFFF;'>Por que funciona?</b><br><br>
            O shadowing ativa sua memória muscular vocal, treina ritmo, entonação e vocabulário simultaneamente — o método mais usado por poliglotas! 🧠
        </div>
        """, unsafe_allow_html=True)

    user_attempt = st.text_area(
        "✍️ Escreva o que você falou ou tente traduzir/explicar a cena em inglês:",
        placeholder="Type here what you said or your version of the scene...",
        height=120,
    )

    feedback_type = st.radio(
        "Tipo de análise:",
        ["🎯 Pronúncia e ritmo", "📝 Gramática", "💬 Vocabulário", "🌟 Análise completa"],
        horizontal=True,
    )

    if st.button("🤖 Analisar com IA", use_container_width=True):
        if not st.session_state.api_key:
            st.error("⚠️ Insira sua API Key da Anthropic na barra lateral.")
        elif not user_attempt.strip():
            st.warning("Escreva algo para analisar!")
        else:
            with st.spinner("Analisando sua prática..."):
                prompt = f"""You are an English teacher specialized in the shadowing method for Brazilian Portuguese speakers with intermediate English level.

The student practiced the following scene from a movie/series:
ORIGINAL: "{scene['en']}"

The student wrote/said:
"{user_attempt}"

Analysis requested: {feedback_type}

Give feedback in Brazilian Portuguese (PT-BR), friendly and encouraging tone. Include:
1. What they did well
2. Specific pronunciation/grammar tips for this scene
3. One key phrase to focus on
4. Encouragement to keep practicing

Keep it concise, practical, and motivating. Use emojis sparingly."""

                response = ask_claude(prompt, st.session_state.api_key)
                if response:
                    st.markdown(f"""
                    <div class='card' style='border-color:#47CFFF; margin-top:1rem;'>
                        <div style='color:#47CFFF; font-weight:700; margin-bottom:0.8rem;'>🤖 Feedback do Professor IA</div>
                        <div style='line-height:1.8;'>{response}</div>
                    </div>
                    """, unsafe_allow_html=True)
                    st.session_state.xp += 15
                    st.success(f"🎉 +15 XP ganhos! Total: {st.session_state.xp} XP")

    st.markdown("---")
    st.markdown("### ➕ Adicionar cena personalizada")
    with st.expander("Adicione sua própria cena de filme ou série"):
        custom_title = st.text_input("Nome da cena (ex: Friends — 'How you doin?')")
        custom_en = st.text_area("Texto em inglês", height=100)
        custom_pt = st.text_area("Tradução em português (opcional)", height=80)

        if st.button("💾 Salvar cena") and custom_title and custom_en:
            if "custom_scenes" not in st.session_state:
                st.session_state.custom_scenes = {}
            st.session_state.custom_scenes[custom_title] = {"en": custom_en, "pt": custom_pt}
            st.success("Cena salva! Reinicie o app para vê-la na lista.")
