import streamlit as st
from utils.claude_api import ask_claude_chat

PERSONAS = {
    "🎓 Prof. Alex — Paciente e didático": {
        "desc": "Explica erros com calma, dá exemplos práticos e foca na evolução gradual.",
        "system": "You are Professor Alex, a patient and didactic English teacher for Brazilian intermediate learners. Always respond in a mix: correct their English gently, then continue the conversation naturally. Use simple but real English. When the student makes mistakes, kindly point them out and show the correct form. Encourage them constantly. Keep responses concise (3-5 sentences max unless explaining grammar).",
    },
    "🎬 Sam — Cinéfilo entusiasmado": {
        "desc": "Adora filmes e séries, usa referências pop, conversa de forma casual e divertida.",
        "system": "You are Sam, an enthusiastic movie and series fan who teaches English through pop culture. You naturally reference movies, shows, quotes. Speak casually and naturally. When the student makes English mistakes, correct them smoothly by repeating their sentence correctly without making it awkward. Keep it fun and conversational. Max 4 sentences per reply.",
    },
    "💼 Jordan — Business English": {
        "desc": "Focado em inglês profissional, entrevistas, apresentações e e-mails corporativos.",
        "system": "You are Jordan, a business English coach. Focus on professional vocabulary, formal communication, job interviews, emails, and presentations. Help the student sound professional in English. Gently correct mistakes and suggest more professional alternatives. Keep responses practical and workplace-oriented.",
    },
    "🌍 Maya — Conversação livre": {
        "desc": "Papo informal sobre qualquer assunto, como uma amiga nativa.",
        "system": "You are Maya, a native English speaker having a casual conversation. Talk about anything the student brings up. Be natural, use contractions, slang occasionally, and speak like a real friend. Subtly model correct English when the student makes errors by using the correct form naturally in your reply. Keep it light and engaging.",
    },
}

TOPIC_STARTERS = {
    "🎬 Filmes e séries": "Let's talk about movies and series! What's the last thing you watched? Did you enjoy it?",
    "✈️ Viagens": "I'd love to hear about travel! Have you ever traveled abroad, or is there a place you'd love to visit?",
    "🍕 Comida e cultura": "Food is such a fun topic! What's your favorite meal? Do you like trying different cuisines?",
    "💼 Trabalho e carreira": "Tell me about what you do for work! What are your career goals?",
    "🎮 Hobbies": "What do you do in your free time? Any hobbies or passions you'd like to share?",
    "🌍 Falar sobre si mesmo": "Let's start simple — tell me about yourself! Where are you from and what do you like?",
}

def render_conversation():
    st.markdown("<h2>🤖 Conversação com IA</h2>", unsafe_allow_html=True)
    st.markdown("<p class='muted-text'>Pratique inglês conversando com um professor IA. Erros serão corrigidos naturalmente.</p>", unsafe_allow_html=True)

    col_p, col_t = st.columns([1, 1])

    with col_p:
        st.markdown("**Escolha seu professor:**")
        persona_name = st.selectbox("Professor", list(PERSONAS.keys()), label_visibility="collapsed")

    with col_t:
        st.markdown("**Tema de conversa (opcional):**")
        topic = st.selectbox("Tema", ["💬 Livre (sem tema)"] + list(TOPIC_STARTERS.keys()), label_visibility="collapsed")

    persona = PERSONAS[persona_name]
    st.markdown(f"<div class='card'><span style='color:#E8FF47; font-weight:600;'>{persona_name}</span><br><span class='muted-text'>{persona['desc']}</span></div>", unsafe_allow_html=True)

    # Controls row
    col_new, col_hint, col_lvl = st.columns([1, 1, 1])
    with col_new:
        if st.button("🔄 Nova conversa", use_container_width=True):
            st.session_state.conversation = []
            st.rerun()
    with col_hint:
        show_hint = st.button("💡 Preciso de ajuda", use_container_width=True)
    with col_lvl:
        correction_level = st.selectbox("Correção", ["🟡 Suave", "🔴 Detalhada", "🟢 Só elogios"], label_visibility="collapsed")

    # Display conversation
    st.markdown("<div style='margin-top:1rem;'>", unsafe_allow_html=True)

    # Auto-start with topic
    if not st.session_state.conversation and topic != "💬 Livre (sem tema)":
        starter = TOPIC_STARTERS.get(topic, "")
        if starter:
            st.session_state.conversation.append({"role": "assistant", "content": starter})

    if not st.session_state.conversation:
        st.markdown("""
        <div style='text-align:center; padding: 2rem; color: #7A7A8A;'>
            <div style='font-size: 2.5rem; margin-bottom: 0.5rem;'>💬</div>
            <div>Comece a conversa escrevendo em inglês abaixo!</div>
            <div style='font-size: 0.85rem; margin-top: 0.5rem;'>Não tenha medo de errar — é assim que se aprende!</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        chat_container = st.container()
        with chat_container:
            for msg in st.session_state.conversation:
                if msg["role"] == "user":
                    st.markdown(f"<div class='msg-user'><span style='font-size:0.75rem; color:#E8FF47; font-weight:600;'>VOCÊ</span><br>{msg['content']}</div>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<div class='msg-ai'><span style='font-size:0.75rem; color:#47CFFF; font-weight:600;'>PROFESSOR IA</span><br>{msg['content']}</div>", unsafe_allow_html=True)

    # Hint button
    if show_hint:
        if not st.session_state.api_key:
            st.error("Insira sua API Key!")
        else:
            context = st.session_state.conversation[-3:] if st.session_state.conversation else []
            hint_prompt = f"The student is practicing English conversation with the topic: {topic}. Give them 3 simple sentence suggestions IN ENGLISH they could say next, with Portuguese translation. Keep it brief and encouraging."
            hint = ask_claude_chat([{"role": "user", "content": hint_prompt}], persona["system"], st.session_state.api_key)
            if hint:
                st.markdown(f"""
                <div class='card' style='border-color:#E8FF47;'>
                    <b style='color:#E8FF47;'>💡 Sugestões do que dizer:</b><br><br>{hint}
                </div>
                """, unsafe_allow_html=True)

    # Input area
    st.markdown("<div style='margin-top:1.5rem;'>", unsafe_allow_html=True)

    correction_instructions = {
        "🟡 Suave": "Correct errors very subtly, mostly by modeling correct English naturally.",
        "🔴 Detalhada": "Explicitly point out grammar/vocabulary errors and explain the correct form in Portuguese.",
        "🟢 Só elogios": "Be very encouraging, only correct critical errors, celebrate every attempt.",
    }

    user_msg = st.text_area(
        "Escreva em inglês:",
        placeholder="Type in English... (e.g.: 'I really enjoy watch movies at weekend')",
        height=100,
        key="conv_input",
    )

    col_send, col_translate = st.columns([2, 1])
    with col_send:
        send = st.button("📤 Enviar mensagem", use_container_width=True)
    with col_translate:
        translate = st.button("🇧🇷 Traduzir para EN", use_container_width=True)

    if translate and user_msg.strip():
        if st.session_state.api_key:
            with st.spinner("Traduzindo..."):
                tr = ask_claude_chat([{"role": "user", "content": f"Translate this to English naturally (intermediate level): {user_msg}"}], "You are a translator. Translate Portuguese to English. Only return the translation, nothing else.", st.session_state.api_key)
                if tr:
                    st.info(f"🇺🇸 Sugestão em inglês: **{tr}**")

    if send and user_msg.strip():
        if not st.session_state.api_key:
            st.error("⚠️ Insira sua API Key na barra lateral.")
        else:
            st.session_state.conversation.append({"role": "user", "content": user_msg})

            correction_note = correction_instructions.get(correction_level, "")
            system = f"{persona['system']}\n\nCorrection style: {correction_note}\n\nIMPORTANT: Always respond in English. If you need to explain grammar, do it briefly in Portuguese at the end."

            with st.spinner("Professor está respondendo..."):
                response = ask_claude_chat(st.session_state.conversation, system, st.session_state.api_key)
                if response:
                    st.session_state.conversation.append({"role": "assistant", "content": response})
                    st.session_state.xp += 10
                    st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)

    # Word count stats
    if st.session_state.conversation:
        user_msgs = [m for m in st.session_state.conversation if m["role"] == "user"]
        total_words = sum(len(m["content"].split()) for m in user_msgs)
        st.markdown(f"<div class='muted-text' style='margin-top:1rem;'>📊 {len(user_msgs)} mensagens enviadas · {total_words} palavras em inglês praticadas · +{len(user_msgs)*10} XP</div>", unsafe_allow_html=True)
