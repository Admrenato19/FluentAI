import streamlit as st
import datetime

def render_progress():
    st.markdown("<h2>📊 Seu Progresso</h2>", unsafe_allow_html=True)
    st.markdown("<p class='muted-text'>Acompanhe sua evolução no inglês e mantenha a sequência!</p>", unsafe_allow_html=True)

    # XP Level system
    xp = st.session_state.xp
    level = xp // 100 + 1
    xp_in_level = xp % 100
    level_names = ["Iniciante", "Explorador", "Estudante", "Comunicador", "Fluente", "Expert", "Mestre"]
    level_name = level_names[min(level - 1, len(level_names) - 1)]

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("⚡ XP Total", xp)
    with col2:
        st.metric("🏅 Nível", f"{level} — {level_name}")
    with col3:
        st.metric("🔥 Sequência", f"{st.session_state.streak} dias")
    with col4:
        total_cards = sum(len(v) for v in st.session_state.get("flashcard_decks", {}).values())
        st.metric("🃏 Total de Cards", total_cards)

    # XP Progress bar
    st.markdown(f"""
    <div class='card' style='margin-top:1rem;'>
        <div style='display:flex; justify-content:space-between; margin-bottom:0.5rem;'>
            <span style='color:#E8FF47; font-weight:700;'>Nível {level}: {level_name}</span>
            <span class='muted-text'>{xp_in_level}/100 XP para próximo nível</span>
        </div>
    </div>
    """, unsafe_allow_html=True)
    st.progress(xp_in_level / 100)

    st.markdown("---")

    # Flashcard stats per deck
    st.markdown("### 🃏 Status dos Flashcards")
    if "flashcard_decks" in st.session_state:
        for deck_name, cards in st.session_state.flashcard_decks.items():
            today = datetime.date.today().isoformat()
            due = sum(1 for c in cards if not c.get("next_review") or c["next_review"] <= today)
            mastered = sum(1 for c in cards if c.get("level", 0) >= 4)
            total = len(cards)

            col_name, col_due, col_mas, col_tot = st.columns([3, 1, 1, 1])
            with col_name:
                st.markdown(f"**{deck_name}**")
            with col_due:
                color = "#FF6B6B" if due > 0 else "#47CFFF"
                st.markdown(f"<span style='color:{color}; font-weight:700;'>{due}</span> <span class='muted-text'>p/ revisar</span>", unsafe_allow_html=True)
            with col_mas:
                st.markdown(f"<span style='color:#E8FF47; font-weight:700;'>{mastered}</span> <span class='muted-text'>dominados</span>", unsafe_allow_html=True)
            with col_tot:
                st.markdown(f"<span class='muted-text'>{total} total</span>", unsafe_allow_html=True)

            if total > 0:
                st.progress(mastered / total)

    st.markdown("---")

    # How to earn XP
    st.markdown("### ⚡ Como ganhar XP")
    xp_table = [
        ("🎬 Shadowing — Análise com IA", "+15 XP"),
        ("💬 Conversação — Por mensagem enviada", "+10 XP"),
        ("🃏 Flashcard — Resposta correta (Fácil)", "+18 XP"),
        ("🃏 Flashcard — Resposta correta (Médio)", "+12 XP"),
        ("✨ Gerar flashcards com IA", "+5 XP por card"),
    ]
    for activity, xp_val in xp_table:
        col_act, col_xp = st.columns([3, 1])
        with col_act:
            st.markdown(f"<div style='padding: 0.3rem 0;'>{activity}</div>", unsafe_allow_html=True)
        with col_xp:
            st.markdown(f"<div style='color:#E8FF47; font-weight:700; text-align:right;'>{xp_val}</div>", unsafe_allow_html=True)

    st.markdown("---")

    # Tips
    st.markdown("### 💡 Dicas para evoluir mais rápido")
    tips = [
        ("🎬", "Shadowing diário", "15–20 minutos por dia de shadowing é mais eficaz do que 2 horas no fim de semana."),
        ("🃏", "Revisão espaçada", "Revise os cards no horário certo — não pule! O intervalo é calculado cientificamente."),
        ("💬", "Conversação sem medo", "Errar faz parte. O professor IA vai te corrigir com gentileza — escreva sem medo!"),
        ("📺", "Assistir com legendas", "Comece com legenda em PT, depois EN, depois sem. Um episódio por dia já faz diferença."),
    ]
    for icon, title, desc in tips:
        st.markdown(f"""
        <div class='card' style='display:flex; gap: 1rem; align-items:flex-start;'>
            <div style='font-size:1.8rem;'>{icon}</div>
            <div>
                <div style='font-weight:700; color:#F0EFE9;'>{title}</div>
                <div class='muted-text'>{desc}</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Reset XP (dev)
    with st.expander("⚙️ Configurações"):
        col_r1, col_r2 = st.columns(2)
        with col_r1:
            if st.button("🔄 Resetar XP e progresso"):
                st.session_state.xp = 0
                st.session_state.streak = 0
                st.rerun()
        with col_r2:
            bonus = st.number_input("Adicionar XP manualmente:", min_value=0, max_value=500, value=0, step=10)
            if st.button("➕ Adicionar XP") and bonus > 0:
                st.session_state.xp += bonus
                st.success(f"+{bonus} XP adicionado!")
                st.rerun()
