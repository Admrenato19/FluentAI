import anthropic
import streamlit as st

def ask_claude(prompt: str, api_key: str, max_tokens: int = 1000) -> str:
    """Send a simple prompt to Claude and return the text response."""
    try:
        client = anthropic.Anthropic(api_key=api_key)
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text
    except anthropic.AuthenticationError:
        st.error("❌ API Key inválida. Verifique sua chave na barra lateral.")
    except anthropic.RateLimitError:
        st.error("⚠️ Limite de requisições atingido. Aguarde alguns segundos.")
    except Exception as e:
        st.error(f"Erro na API: {str(e)}")
    return ""


def ask_claude_chat(messages: list, system: str, api_key: str, max_tokens: int = 800) -> str:
    """Send a conversation to Claude with a system prompt."""
    try:
        client = anthropic.Anthropic(api_key=api_key)
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return message.content[0].text
    except anthropic.AuthenticationError:
        st.error("❌ API Key inválida. Verifique sua chave na barra lateral.")
    except anthropic.RateLimitError:
        st.error("⚠️ Limite de requisições atingido. Aguarde alguns segundos.")
    except Exception as e:
        st.error(f"Erro na API: {str(e)}")
    return ""
